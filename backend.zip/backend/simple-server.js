const http = require('http');
const url = require('url');
const { v4: uuidv4 } = require('uuid');

// Simple in-memory database
const users = [];
const vendors = [];
const customers = [];

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Content-Type': 'application/json'
};

// Helper function to send JSON response
function sendJSON(res, statusCode, data) {
  res.writeHead(statusCode, corsHeaders);
  res.end(JSON.stringify(data));
}

// Helper function to parse POST data
function parsePostData(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(body));
      } catch (e) {
        resolve({});
      }
    });
  });
}

// Routes
const routes = {
  'GET /health': () => ({
    status: 'ok',
    timestamp: new Date().toISOString(),
    message: 'MarketMind Backend is running',
    version: '1.0.0'
  }),

  'POST /api/auth/register': async (req) => {
    const data = await parsePostData(req);
    const { email, password, firstName, lastName, userType } = data;
    
    const newUser = {
      id: uuidv4(),
      email,
      firstName,
      lastName,
      userType,
      createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    
    return {
      success: true,
      message: 'User registered successfully',
      data: {
        user: newUser,
        token: 'demo-jwt-token-' + uuidv4()
      }
    };
  },

  'POST /api/auth/login': async (req) => {
    const data = await parsePostData(req);
    const { email, password } = data;
    
    const user = users.find(u => u.email === email);
    
    if (user) {
      return {
        success: true,
        message: 'Login successful',
        data: {
          user,
          token: 'demo-jwt-token-' + uuidv4()
        }
      };
    } else {
      return {
        success: false,
        message: 'Invalid credentials'
      };
    }
  },

  'GET /api/analytics/dashboard': () => ({
    success: true,
    data: {
      totalRevenue: 124563,
      activeCustomers: 2847,
      conversionRate: 3.8,
      aiScore: 94.2,
      salesTrends: [
        { month: 'Jan', revenue: 65000 },
        { month: 'Feb', revenue: 78000 },
        { month: 'Mar', revenue: 90000 },
        { month: 'Apr', revenue: 81000 },
        { month: 'May', revenue: 96000 },
        { month: 'Jun', revenue: 124563 }
      ],
      customerSegments: [
        { segment: 'High Value', count: 342 },
        { segment: 'New', count: 567 },
        { segment: 'At Risk', count: 47 },
        { segment: 'Regular', count: 1234 },
        { segment: 'VIP', count: 657 }
      ]
    }
  }),

  'POST /api/content/generate': async (req) => {
    const data = await parsePostData(req);
    const { contentType, audience } = data;
    
    const templates = {
      email: {
        new: {
          subject: "Welcome to MarketMind! 🎉",
          body: "Hi {{name}},\n\nWelcome to our community! We're excited to have you on board. As a new member, you'll receive:\n\n• Personalized product recommendations\n• Exclusive member-only offers\n• Early access to new features\n\nGet started with our special 15% discount on your first purchase!\n\nBest regards,\nThe MarketMind Team"
        },
        vip: {
          subject: "Exclusive VIP Offer Just for You 💎",
          body: "Dear {{name}},\n\nAs one of our most valued customers, we wanted to thank you with an exclusive offer:\n\n• 25% discount on your next purchase\n• Free priority shipping\n• Early access to new collection\n\nYour loyalty means everything to us. Use code VIP25 at checkout.\n\nWarmly,\nThe MarketMind VIP Team"
        }
      },
      social: {
        new: "🚀 New to MarketMind? Discover how AI can transform your business! Get 15% off your first order. #AI #Marketing #Sales #Innovation",
        vip: "💎 VIP Exclusive! Our top customers get special treatment. 25% off + free shipping this week only. Don't miss out! #VIP #Exclusive #Premium"
      }
    };
    
    const content = templates[contentType]?.[audience] || templates.email.new;
    
    return {
      success: true,
      data: content
    };
  },

  'GET /api/automation/workflows': () => ({
    success: true,
    data: [
      {
        id: 1,
        name: 'Welcome Series',
        description: 'New customer onboarding',
        status: 'active',
        performance: {
          openRate: 68.4,
          clickRate: 24.7,
          conversionRate: 12.3
        }
      },
      {
        id: 2,
        name: 'Abandoned Cart Recovery',
        description: 'Recover lost sales',
        status: 'active',
        performance: {
          openRate: 72.1,
          clickRate: 31.2,
          conversionRate: 18.9
        }
      },
      {
        id: 3,
        name: 'VIP Customer Nurturing',
        description: 'High-value customer care',
        status: 'paused',
        performance: {
          openRate: 85.3,
          clickRate: 42.7,
          conversionRate: 28.4
        }
      }
    ]
  }),

  'GET /api/analytics/ai-insights': () => ({
    success: true,
    data: {
      predictiveLeadScoring: {
        topLead: {
          name: 'John Doe',
          email: 'john@example.com',
          score: 92,
          probability: 'High'
        }
      },
      customerSegmentation: {
        highValue: 342,
        new: 567,
        atRisk: 47
      },
      churnPrediction: {
        atRiskCustomers: 47,
        warningThreshold: 0.7
      }
    }
  })
};

// Create HTTP server
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const method = req.method;
  const pathname = parsedUrl.pathname;
  const routeKey = `${method} ${pathname}`;

  // Handle CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(200, corsHeaders);
    res.end();
    return;
  }

  console.log(`${new Date().toISOString()} - ${method} ${pathname}`);

  // Route handling
  if (routes[routeKey]) {
    try {
      const result = await routes[routeKey](req);
      sendJSON(res, 200, result);
    } catch (error) {
      console.error('Route error:', error);
      sendJSON(res, 500, {
        success: false,
        message: 'Internal server error',
        error: error.message
      });
    }
  } else {
    sendJSON(res, 404, {
      success: false,
      message: 'Route not found',
      availableRoutes: Object.keys(routes)
    });
  }
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 MarketMind Backend Server is running!`);
  console.log(`📍 Local: http://localhost:${PORT}`);
  console.log(`📍 Network: http://0.0.0.0:${PORT}`);
  console.log(`🔗 Health Check: http://localhost:${PORT}/health`);
  console.log(`\n📊 Available API Endpoints:`);
  Object.keys(routes).forEach(route => {
    console.log(`   ${route}`);
  });
  console.log(`\n🌐 Demo URL: file:///c:/Users/Durga%20Prasad/OneDrive/Desktop/market%20mind/deploy-demo.html`);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down server gracefully...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});
