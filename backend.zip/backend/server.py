#!/usr/bin/env python3
import json
import uuid
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import threading
import time

# In-memory database
users = []
vendors = []
customers = []

class MarketMindAPI(BaseHTTPRequestHandler):
    def set_cors_headers(self):
        """Set CORS headers for all responses"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.send_header('Content-Type', 'application/json')

    def do_OPTIONS(self):
        """Handle preflight requests"""
        self.send_response(200)
        self.set_cors_headers()
        self.end_headers()

    def do_GET(self):
        """Handle GET requests"""
        self.send_response(200)
        self.set_cors_headers()
        self.end_headers()
        
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        print(f"{datetime.now().isoformat()} - GET {path}")
        
        if path == '/health':
            response = {
                'status': 'ok',
                'timestamp': datetime.now().isoformat(),
                'message': 'MarketMind Backend is running',
                'version': '1.0.0'
            }
        elif path == '/api/analytics/dashboard':
            response = {
                'success': True,
                'data': {
                    'totalRevenue': 124563,
                    'activeCustomers': 2847,
                    'conversionRate': 3.8,
                    'aiScore': 94.2,
                    'salesTrends': [
                        {'month': 'Jan', 'revenue': 65000},
                        {'month': 'Feb', 'revenue': 78000},
                        {'month': 'Mar', 'revenue': 90000},
                        {'month': 'Apr', 'revenue': 81000},
                        {'month': 'May', 'revenue': 96000},
                        {'month': 'Jun', 'revenue': 124563}
                    ],
                    'customerSegments': [
                        {'segment': 'High Value', 'count': 342},
                        {'segment': 'New', 'count': 567},
                        {'segment': 'At Risk', 'count': 47},
                        {'segment': 'Regular', 'count': 1234},
                        {'segment': 'VIP', 'count': 657}
                    ]
                }
            }
        elif path == '/api/automation/workflows':
            response = {
                'success': True,
                'data': [
                    {
                        'id': 1,
                        'name': 'Welcome Series',
                        'description': 'New customer onboarding',
                        'status': 'active',
                        'performance': {
                            'openRate': 68.4,
                            'clickRate': 24.7,
                            'conversionRate': 12.3
                        }
                    },
                    {
                        'id': 2,
                        'name': 'Abandoned Cart Recovery',
                        'description': 'Recover lost sales',
                        'status': 'active',
                        'performance': {
                            'openRate': 72.1,
                            'clickRate': 31.2,
                            'conversionRate': 18.9
                        }
                    },
                    {
                        'id': 3,
                        'name': 'VIP Customer Nurturing',
                        'description': 'High-value customer care',
                        'status': 'paused',
                        'performance': {
                            'openRate': 85.3,
                            'clickRate': 42.7,
                            'conversionRate': 28.4
                        }
                    }
                ]
            }
        elif path == '/api/analytics/ai-insights':
            response = {
                'success': True,
                'data': {
                    'predictiveLeadScoring': {
                        'topLead': {
                            'name': 'John Doe',
                            'email': 'john@example.com',
                            'score': 92,
                            'probability': 'High'
                        }
                    },
                    'customerSegmentation': {
                        'highValue': 342,
                        'new': 567,
                        'atRisk': 47
                    },
                    'churnPrediction': {
                        'atRiskCustomers': 47,
                        'warningThreshold': 0.7
                    }
                }
            }
        else:
            response = {
                'success': False,
                'message': 'Route not found',
                'availableRoutes': [
                    'GET /health',
                    'GET /api/analytics/dashboard',
                    'GET /api/automation/workflows',
                    'GET /api/analytics/ai-insights',
                    'POST /api/auth/register',
                    'POST /api/auth/login',
                    'POST /api/content/generate'
                ]
            }
        
        self.wfile.write(json.dumps(response, indent=2).encode())

    def do_POST(self):
        """Handle POST requests"""
        self.send_response(200)
        self.set_cors_headers()
        self.end_headers()
        
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        print(f"{datetime.now().isoformat()} - POST {path}")
        
        # Read POST data
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data.decode('utf-8'))
        except:
            data = {}
        
        if path == '/api/auth/register':
            user_data = {
                'id': str(uuid.uuid4()),
                'email': data.get('email', ''),
                'firstName': data.get('firstName', ''),
                'lastName': data.get('lastName', ''),
                'userType': data.get('userType', 'customer'),
                'createdAt': datetime.now().isoformat()
            }
            users.append(user_data)
            
            response = {
                'success': True,
                'message': 'User registered successfully',
                'data': {
                    'user': user_data,
                    'token': f'demo-jwt-token-{uuid.uuid4()}'
                }
            }
            
        elif path == '/api/auth/login':
            email = data.get('email', '')
            user = next((u for u in users if u['email'] == email), None)
            
            if user:
                response = {
                    'success': True,
                    'message': 'Login successful',
                    'data': {
                        'user': user,
                        'token': f'demo-jwt-token-{uuid.uuid4()}'
                    }
                }
            else:
                response = {
                    'success': False,
                    'message': 'Invalid credentials'
                }
                
        elif path == '/api/content/generate':
            content_type = data.get('contentType', 'email')
            audience = data.get('audience', 'new')
            
            templates = {
                'email': {
                    'new': {
                        'subject': "Welcome to MarketMind! 🎉",
                        'body': "Hi {{name}},\n\nWelcome to our community! We're excited to have you on board. As a new member, you'll receive:\n\n• Personalized product recommendations\n• Exclusive member-only offers\n• Early access to new features\n\nGet started with our special 15% discount on your first purchase!\n\nBest regards,\nThe MarketMind Team"
                    },
                    'vip': {
                        'subject': "Exclusive VIP Offer Just for You 💎",
                        'body': "Dear {{name}},\n\nAs one of our most valued customers, we wanted to thank you with an exclusive offer:\n\n• 25% discount on your next purchase\n• Free priority shipping\n• Early access to new collection\n\nYour loyalty means everything to us. Use code VIP25 at checkout.\n\nWarmly,\nThe MarketMind VIP Team"
                    }
                },
                'social': {
                    'new': "🚀 New to MarketMind? Discover how AI can transform your business! Get 15% off your first order. #AI #Marketing #Sales #Innovation",
                    'vip': "💎 VIP Exclusive! Our top customers get special treatment. 25% off + free shipping this week only. Don't miss out! #VIP #Exclusive #Premium"
                }
            }
            
            content = templates.get(content_type, {}).get(audience, templates['email']['new'])
            
            response = {
                'success': True,
                'data': content
            }
        else:
            response = {
                'success': False,
                'message': 'Route not found'
            }
        
        self.wfile.write(json.dumps(response, indent=2).encode())

    def log_message(self, format, *args):
        """Override to prevent default logging"""
        pass

def run_server():
    """Run the HTTP server"""
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, MarketMindAPI)
    
    print("🚀 MarketMind Backend Server is running!")
    print(f"📍 Local: http://localhost:8000")
    print(f"📍 Network: http://0.0.0.0:8000")
    print(f"🔗 Health Check: http://localhost:8000/health")
    print(f"\n📊 Available API Endpoints:")
    print("   GET /health")
    print("   GET /api/analytics/dashboard")
    print("   GET /api/automation/workflows")
    print("   GET /api/analytics/ai-insights")
    print("   POST /api/auth/register")
    print("   POST /api/auth/login")
    print("   POST /api/content/generate")
    print(f"\n🌐 Demo URL: file:///c:/Users/Durga%20Prasad/OneDrive/Desktop/market%20mind/deploy-demo.html")
    print(f"\n⚡ Server is ready to handle requests!")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Shutting down server gracefully...")
        httpd.server_close()
        print("✅ Server closed")

if __name__ == '__main__':
    run_server()
