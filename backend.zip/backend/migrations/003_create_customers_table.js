exports.up = function(knex) {
  return knex.schema.createTable('customers', function(table) {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    table.string('customer_id').unique().notNullable(); // Customer-friendly ID
    table.string('company_name').nullable(); // For B2B customers
    table.string('job_title').nullable();
    table.jsonb('shipping_address').nullable();
    table.jsonb('billing_address').nullable();
    table.date('birth_date').nullable();
    table.enum('gender', ['male', 'female', 'other', 'prefer_not_to_say']).nullable();
    table.string('referral_source').nullable(); // How they found us
    table.string('customer_segment').nullable(); // VIP, regular, etc.
    table.decimal('lifetime_value', 12, 2).defaultTo(0); // Total value to business
    table.decimal('average_order_value', 10, 2).defaultTo(0);
    table.integer('total_orders').defaultTo(0);
    table.decimal('total_spent', 12, 2).defaultTo(0);
    table.date('first_purchase_date').nullable();
    table.date('last_purchase_date').nullable();
    table.integer('purchase_frequency_days').nullable();
    table.decimal('churn_probability', 3, 2).defaultTo(0); // AI-calculated
    table.decimal('loyalty_score', 3, 2).defaultTo(0); // AI-calculated
    table.jsonb('preferences').nullable(); // Product preferences, communication preferences
    table.jsonb('behavior_data').nullable(); // Browsing behavior, interaction history
    table.boolean('email_marketing').defaultTo(true);
    table.boolean('sms_marketing').defaultTo(false);
    table.boolean('marketing_consent').defaultTo(true);
    table.string('loyalty_tier').defaultTo('bronze'); // bronze, silver, gold, platinum
    table.integer('loyalty_points').defaultTo(0);
    table.jsonb('tags').nullable(); // Customer tags for segmentation
    table.timestamps(true, true);
    
    // Indexes for performance
    table.index(['user_id']);
    table.index(['customer_id']);
    table.index(['customer_segment']);
    table.index(['loyalty_tier']);
    table.index(['churn_probability']);
    table.index(['loyalty_score']);
    table.index(['last_purchase_date']);
    table.index(['created_at']);
    
    // Full-text search index
    table.raw(`CREATE INDEX customers_search_idx ON customers USING gin(to_tsvector('english', customer_id || ' ' || COALESCE(company_name, '') || ' ' || first_name || ' ' || last_name))`);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('customers');
};
