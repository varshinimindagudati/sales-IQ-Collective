exports.up = function(knex) {
  return knex.schema.createTable('users', function(table) {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('email').notNullable().unique();
    table.string('password_hash').notNullable();
    table.string('first_name').notNullable();
    table.string('last_name').notNullable();
    table.string('phone').nullable();
    table.enum('user_type', ['vendor', 'customer', 'admin']).notNullable().defaultTo('customer');
    table.enum('status', ['active', 'inactive', 'suspended']).notNullable().defaultTo('active');
    table.jsonb('profile').nullable(); // Store additional profile data
    table.jsonb('preferences').nullable(); // User preferences
    table.timestamp('last_login').nullable();
    table.timestamp('email_verified_at').nullable();
    table.string('email_verification_token').nullable();
    table.timestamp('password_reset_expires').nullable();
    table.string('password_reset_token').nullable();
    table.timestamps(true, true);
    
    // Indexes for performance
    table.index(['email']);
    table.index(['user_type']);
    table.index(['status']);
    table.index(['created_at']);
    
    // Full-text search index
    table.raw(`CREATE INDEX users_search_idx ON users USING gin(to_tsvector('english', first_name || ' ' || last_name || ' ' || email))`);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('users');
};
