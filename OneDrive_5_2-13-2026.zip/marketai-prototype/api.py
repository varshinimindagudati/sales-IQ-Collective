# MarketAI Suite - Serverless API for Vercel/Netlify
import json
import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import random

app = Flask(__name__)
CORS(app)

# Mock data for demo
campaigns = []
leads = []
users = []

@app.route('/')
def home():
    return jsonify({
        "message": "🚀 MarketAI Suite - Live API",
        "status": "Active",
        "features": [
            "AI Campaign Generator",
            "ML Lead Scoring", 
            "Analytics Dashboard",
            "User Management"
        ],
        "endpoints": {
            "campaigns": "/api/campaigns",
            "leads": "/api/leads", 
            "analytics": "/api/analytics",
            "register": "/api/register",
            "login": "/api/login"
        }
    })

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    user = {
        "id": len(users) + 1,
        "username": data.get('username'),
        "email": data.get('email'),
        "created_at": "2024-01-01"
    }
    users.append(user)
    return jsonify({"success": True, "user": user})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    user = next((u for u in users if u['email'] == data.get('email')), None)
    if user:
        return jsonify({"success": True, "user": user})
    return jsonify({"success": False, "message": "User not found"})

@app.route('/api/campaigns', methods=['GET', 'POST'])
def campaigns_api():
    if request.method == 'POST':
        data = request.get_json()
        campaign = {
            "id": len(campaigns) + 1,
            "product": data.get('product'),
            "audience": data.get('audience'), 
            "platform": data.get('platform'),
            "content": generate_campaign_content(data),
            "created_at": "2024-01-01",
            "conversions": random.randint(0, 100)
        }
        campaigns.append(campaign)
        return jsonify({"success": True, "campaign": campaign})
    
    return jsonify({"campaigns": campaigns})

@app.route('/api/leads', methods=['GET', 'POST'])
def leads_api():
    if request.method == 'POST':
        data = request.get_json()
        score = calculate_lead_score(data)
        lead = {
            "id": len(leads) + 1,
            "name": data.get('name'),
            "email": data.get('email'),
            "company": data.get('company'),
            "score": score,
            "status": "hot" if score >= 75 else "warm" if score >= 50 else "cold",
            "created_at": "2024-01-01"
        }
        leads.append(lead)
        return jsonify({"success": True, "lead": lead})
    
    return jsonify({"leads": leads})

@app.route('/api/analytics')
def analytics():
    return jsonify({
        "total_campaigns": len(campaigns),
        "total_leads": len(leads),
        "avg_score": sum(l['score'] for l in leads) / len(leads) if leads else 0,
        "total_conversions": sum(c['conversions'] for c in campaigns),
        "platforms": list(set(c['platform'] for c in campaigns)),
        "hot_leads": len([l for l in leads if l['status'] == 'hot'])
    })

def generate_campaign_content(data):
    return f"""
🚀 AI-Generated Campaign for {data.get('product')}

🎯 Target Audience: {data.get('audience')}
📱 Platform: {data.get('platform')}

1. POSITIONING:
   - Premium quality solution for {data.get('audience')}
   - Cutting-edge technology meets user needs
   - Competitive advantage through innovation

2. CONTENT IDEAS:
   - Educational content showcasing benefits
   - Customer success stories and testimonials
   - Interactive demos and tutorials
   - Industry insights and thought leadership
   - Limited-time promotional offers

3. AD COPY VARIATIONS:
   A) "Transform your {data.get('audience')} experience with {data.get('product')}. Try it free today!"
   B) "Join thousands of satisfied {data.get('audience')} using {data.get('product')}. Results guaranteed."
   C) "The ultimate {data.get('product')} solution for {data.get('audience')}. Start your journey now."

4. KEY PERFORMANCE INDICATORS:
   - Conversion Rate: Target 3-5%
   - Click-Through Rate: Target 2-4%
   - Cost Per Acquisition: Target $50-100
   - Return on Ad Spend: Target 300%+

📈 Campaign ready for launch on {data.get('platform')}!
"""

def calculate_lead_score(data):
    score = 50  # Base score
    
    # Budget scoring
    budget = float(data.get('budget', 0))
    if budget >= 50000:
        score += 30
    elif budget >= 10000:
        score += 20
    elif budget >= 1000:
        score += 10
    
    # Timeline scoring
    timeline = data.get('timeline', '')
    if 'immediate' in timeline.lower():
        score += 20
    elif '1-3' in timeline:
        score += 15
    elif '3-6' in timeline:
        score += 10
    
    # Interest level scoring
    interest = data.get('interest_level', '').lower()
    if 'very high' in interest:
        score += 20
    elif 'high' in interest:
        score += 15
    elif 'medium' in interest:
        score += 10
    
    return min(100, score)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
