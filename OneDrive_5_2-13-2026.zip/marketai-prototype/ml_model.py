import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import joblib
import os

class LeadScoringModel:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.label_encoders = {}
        self.is_trained = False
        
    def prepare_data(self, df):
        """Prepare data for training"""
        # Create sample data if real data not available
        if df.empty:
            # Generate sample data
            np.random.seed(42)
            n_samples = 1000
            
            data = {
                'budget': np.random.uniform(1000, 100000, n_samples),
                'timeline': np.random.choice(['immediate', '1-3 months', '3-6 months', '6+ months'], n_samples),
                'interest_level': np.random.choice(['low', 'medium', 'high', 'very high'], n_samples),
                'source': np.random.choice(['website', 'referral', 'social', 'email', 'cold_call'], n_samples),
                'converted': np.random.choice([0, 1], n_samples, p=[0.7, 0.3])
            }
            df = pd.DataFrame(data)
        
        # Encode categorical variables
        categorical_columns = ['timeline', 'interest_level', 'source']
        
        for col in categorical_columns:
            if col in df.columns:
                if col not in self.label_encoders:
                    self.label_encoders[col] = LabelEncoder()
                df[col] = self.label_encoders[col].fit_transform(df[col].astype(str))
        
        return df
    
    def train(self, df):
        """Train the model"""
        df = self.prepare_data(df.copy())
        
        # Features and target
        feature_columns = ['budget', 'timeline', 'interest_level', 'source']
        X = df[feature_columns]
        y = df['converted'] if 'converted' in df.columns else np.random.choice([0, 1], len(df))
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train model
        self.model.fit(X_train, y_train)
        self.is_trained = True
        
        # Save model
        joblib.dump(self.model, 'lead_scoring_model.pkl')
        joblib.dump(self.label_encoders, 'label_encoders.pkl')
        
        return self.model.score(X_test, y_test)
    
    def predict_score(self, budget, timeline, interest_level, source):
        """Predict lead score (0-100)"""
        if not self.is_trained:
            # Load model if available
            if os.path.exists('lead_scoring_model.pkl'):
                self.model = joblib.load('lead_scoring_model.pkl')
                self.label_encoders = joblib.load('label_encoders.pkl')
                self.is_trained = True
            else:
                return 50.0  # Default score
        
        # Prepare input data
        input_data = pd.DataFrame({
            'budget': [budget],
            'timeline': [timeline],
            'interest_level': [interest_level],
            'source': [source]
        })
        
        # Encode categorical variables
        for col in ['timeline', 'interest_level', 'source']:
            if col in self.label_encoders:
                try:
                    input_data[col] = self.label_encoders[col].transform([input_data[col].iloc[0]])
                except:
                    input_data[col] = 0  # Default for unknown values
            else:
                input_data[col] = 0
        
        # Predict probability
        probability = self.model.predict_proba(input_data)[0][1]
        score = probability * 100
        
        return round(score, 2)

# Global model instance
lead_model = LeadScoringModel()
