# 🚀 MarketAI Suite - Deployment Guide

## Quick Deployment Options

### Option 1: Render (Recommended - Free & Easy)

1. **Create Render Account**
   - Go to https://render.com
   - Sign up with GitHub

2. **Deploy Your App**
   - Click "New +" → "Web Service"
   - Connect your GitHub repository
   - Use these settings:
     ```
     Name: marketai-suite
     Environment: Python 3
     Build Command: pip install -r requirements.txt
     Start Command: gunicorn app:app
     ```

3. **Add Environment Variables**
   - Go to Service → Environment
   - Add: `GROQ_API_KEY` = your_groq_api_key

4. **Deploy** - Your app will be live at: `https://marketai-suite.onrender.com`

---

### Option 2: Railway (Alternative)

1. **Go to https://railway.app**
2. **Connect GitHub**
3. **Deploy from template**
4. **Add GROQ_API_KEY environment variable**

---

### Option 3: Vercel (Serverless)

1. **Install Vercel CLI**
2. **Run:** `vercel --prod`
3. **Add environment variables**

---

## 🌐 Live Access

Once deployed, your MarketAI Suite will be available at:

**Main Features:**
- 🏠 **Home Page:** Your live landing page
- 🔐 **Login/Register:** User authentication
- 📊 **Dashboard:** Analytics and insights
- 🚀 **Campaign Generator:** AI-powered campaigns
- 🎯 **Lead Scoring:** ML-based lead analysis

## 🔑 Required Setup

1. **Get Groq API Key:**
   - Visit https://console.groq.com
   - Create free account
   - Generate API key
   - Add to deployment environment variables

2. **Test Your Live App:**
   - Register a new account
   - Create your first AI campaign
   - Test lead scoring feature

## 📱 Mobile Ready

Your deployed app is fully responsive and works on:
- Desktop browsers
- Tablets
- Mobile phones

## 🎯 Next Steps

After deployment:
1. Share your live URL with users
2. Monitor analytics dashboard
3. Create marketing campaigns
4. Score and manage leads

Your MarketAI Suite is now a live SaaS application! 🎉
