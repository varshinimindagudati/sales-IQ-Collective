import os
import pandas as pd
import requests
import plotly.graph_objs as go
import plotly.utils
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_required, current_user
from dotenv import load_dotenv
from models import db, User, Campaign, Lead
from auth import auth_bp
from ml_model import lead_model

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///marketai.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/auth')

# Groq Setup
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

def call_groq(prompt):
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "llama3-70b-8192",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.7
    }

    response = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers=headers,
        json=data
    )

    return response.json()["choices"][0]["message"]["content"]

# Routes
@app.route("/")
def home():
    return render_template('home.html')

@app.route("/dashboard")
@login_required
def dashboard():
    # Get user statistics
    total_campaigns = Campaign.query.filter_by(user_id=current_user.id).count()
    total_leads = Lead.query.filter_by(user_id=current_user.id).count()
    
    # Calculate average lead score
    leads = Lead.query.filter_by(user_id=current_user.id).all()
    avg_score = sum(lead.score for lead in leads) / len(leads) if leads else 0
    
    # Total conversions
    total_conversions = sum(campaign.conversions for campaign in 
                          Campaign.query.filter_by(user_id=current_user.id).all())
    
    # Recent campaigns
    recent_campaigns = Campaign.query.filter_by(user_id=current_user.id)\
                                   .order_by(Campaign.created_at.desc())\
                                   .limit(5).all()
    
    return render_template('dashboard.html', 
                         total_campaigns=total_campaigns,
                         total_leads=total_leads,
                         avg_score=avg_score,
                         total_conversions=total_conversions,
                         recent_campaigns=recent_campaigns)

@app.route("/campaign", methods=["GET", "POST"])
@login_required
def campaign():
    if request.method == "POST":
        product = request.form["product"]
        audience = request.form["audience"]
        platform = request.form["platform"]

        prompt = f"""
You are a senior marketing strategist.

Create a professional marketing campaign.

Product: {product}
Audience: {audience}
Platform: {platform}

Include:
1. Positioning
2. 5 content ideas
3. 3 ad copies
4. KPIs
"""

        result = call_groq(prompt)

        # Save campaign to database
        new_campaign = Campaign(
            user_id=current_user.id,
            product=product,
            audience=audience,
            platform=platform,
            content=result
        )
        db.session.add(new_campaign)
        db.session.commit()

        return render_template('campaign_result.html', result=result, campaign=new_campaign)

    return render_template('campaign.html')

@app.route("/analytics")
@login_required
def analytics():
    # Get user's campaigns
    campaigns = Campaign.query.filter_by(user_id=current_user.id).all()
    leads = Lead.query.filter_by(user_id=current_user.id).all()
    
    # Create charts data
    campaign_data = []
    platform_data = {}
    
    for campaign in campaigns:
        campaign_data.append({
            'name': campaign.product,
            'impressions': campaign.impressions,
            'clicks': campaign.clicks,
            'conversions': campaign.conversions
        })
        
        if campaign.platform in platform_data:
            platform_data[campaign.platform] += 1
        else:
            platform_data[campaign.platform] = 1
    
    # Lead score distribution
    score_ranges = {'0-25': 0, '26-50': 0, '51-75': 0, '76-100': 0}
    for lead in leads:
        if lead.score <= 25:
            score_ranges['0-25'] += 1
        elif lead.score <= 50:
            score_ranges['26-50'] += 1
        elif lead.score <= 75:
            score_ranges['51-75'] += 1
        else:
            score_ranges['76-100'] += 1
    
    return render_template('analytics.html', 
                         campaigns=campaigns,
                         leads=leads,
                         campaign_data=campaign_data,
                         platform_data=platform_data,
                         score_ranges=score_ranges)

@app.route("/lead_scoring", methods=["GET", "POST"])
@login_required
def lead_scoring():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        company = request.form.get("company", "")
        budget = float(request.form.get("budget", 0))
        timeline = request.form.get("timeline", "")
        interest_level = request.form.get("interest_level", "")
        source = request.form.get("source", "")
        
        # Calculate lead score
        score = lead_model.predict_score(budget, timeline, interest_level, source)
        
        # Determine status based on score
        if score >= 75:
            status = "hot"
        elif score >= 50:
            status = "warm"
        else:
            status = "cold"
        
        # Save lead to database
        new_lead = Lead(
            user_id=current_user.id,
            name=name,
            email=email,
            company=company,
            budget=budget,
            timeline=timeline,
            interest_level=interest_level,
            source=source,
            score=score,
            status=status
        )
        db.session.add(new_lead)
        db.session.commit()
        
        return render_template('lead_result.html', lead=new_lead)
    
    return render_template('lead_scoring.html')

@app.route("/api/train_model")
@login_required
def train_model():
    try:
        # Load marketing data for training
        marketing_df = pd.read_csv("data/marketing_data.csv")
        accuracy = lead_model.train(marketing_df)
        return jsonify({"success": True, "accuracy": accuracy})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000)
