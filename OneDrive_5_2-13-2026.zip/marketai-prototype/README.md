# MarketAI Prototype

A professional marketing AI prototype built with Flask and Groq API.

## 🚀 Setup Instructions

### 1. Create Virtual Environment
```bash
python -m venv venv
```

### 2. Activate Environment
**Windows:**
```bash
venv\Scripts\activate
```

**Mac/Linux:**
```bash
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Setup API Key
1. Get your Groq API key from https://console.groq.com
2. Update `.env` file with your key:
```
GROQ_API_KEY=your_real_key_here
```

### 5. Add Datasets
Download and place these CSV files in the `data/` folder:
- Marketing Dataset: https://www.kaggle.com/datasets/jackdaoud/marketing-data
- Lead Scoring Dataset: https://www.kaggle.com/datasets/ashydv/marketing-lead-scoring

### 6. Run Application
```bash
python app.py
```

Open http://127.0.0.1:5000 in your browser.

## 🎯 Features

- **Campaign Generator**: AI-powered marketing campaign creation
- **Dataset Analytics**: Basic analytics on marketing data
- **Professional UI**: Clean, functional web interface

## 🏗️ Architecture

```
User Input → Flask Backend → Groq AI API → AI Generated Campaign → Display
Dataset → Pandas Analysis → Analytics Page
```

## 📦 Dependencies

- Flask: Web framework
- requests: HTTP client for API calls
- python-dotenv: Environment variable management
- pandas: Data analysis
- scikit-learn: Machine learning utilities
- SQLAlchemy: Database ORM
- matplotlib: Data visualization

## 🚀 Next Level Upgrades

- ML lead scoring model
- Dashboard with charts
- User login system
- Database storage
- React frontend
- Cloud deployment
