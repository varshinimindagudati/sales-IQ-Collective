#!/usr/bin/env python3
"""
MarketAI Suite - One-Click Deployment Script
Deploys to multiple platforms automatically
"""

import os
import subprocess
import webbrowser
from pathlib import Path

def create_deploy_script():
    """Create deployment scripts for different platforms"""
    
    # Render deployment script
    render_script = """#!/bin/bash
# MarketAI Suite - Render Deployment
echo "🚀 Deploying MarketAI Suite to Render..."

# Check if git is initialized
if [ ! -d ".git" ]; then
    git init
    git add .
    git commit -m "Initial commit: MarketAI Suite"
fi

echo "✅ Git repository ready!"
echo "🌐 Go to https://render.com to deploy:"
echo "1. Connect your GitHub repository"
echo "2. Use render.yaml configuration"
echo "3. Add GROQ_API_KEY environment variable"
echo "4. Deploy and get your live URL!"

# Open Render in browser
python -c "import webbrowser; webbrowser.open('https://render.com')"
"""
    
    # Railway deployment script
    railway_script = """#!/bin/bash
# MarketAI Suite - Railway Deployment
echo "🚂 Deploying MarketAI Suite to Railway..."

# Check if git is initialized
if [ ! -d ".git" ]; then
    git init
    git add .
    git commit -m "Initial commit: MarketAI Suite"
fi

echo "✅ Git repository ready!"
echo "🌐 Go to https://railway.app to deploy:"
echo "1. Connect your GitHub repository"
echo "2. New Project → Deploy from GitHub"
echo "3. Add GROQ_API_KEY environment variable"
echo "4. Deploy and get your live URL!"

# Open Railway in browser
python -c "import webbrowser; webbrowser.open('https://railway.app')"
"""
    
    # Netlify deployment script
    netlify_script = """#!/bin/bash
# MarketAI Suite - Netlify Deployment
echo "🌐 Deploying MarketAI Suite to Netlify..."

# Create static version for Netlify
mkdir -p dist
cp index.html dist/
cp -r templates dist/
cp -r static dist/ 2>/dev/null || true

echo "✅ Static files ready!"
echo "🌐 Go to https://netlify.com to deploy:"
echo "1. Drag and drop the 'dist' folder"
echo "2. Your site will be live instantly!"

# Open Netlify in browser
python -c "import webbrowser; webbrowser.open('https://netlify.com')"
"""
    
    with open('deploy-render.sh', 'w') as f:
        f.write(render_script)
    
    with open('deploy-railway.sh', 'w') as f:
        f.write(railway_script)
    
    with open('deploy-netlify.sh', 'w') as f:
        f.write(netlify_script)
    
    # Make scripts executable
    os.chmod('deploy-render.sh', 0o755)
    os.chmod('deploy-railway.sh', 0o755)
    os.chmod('deploy-netlify.sh', 0o755)

def show_deployment_options():
    """Display deployment options"""
    
    print("""
🚀 MARKETAI SUITE - DEPLOYMENT CENTER
=====================================

Choose your deployment platform:

1️⃣  RENDER (Recommended - FREE & Easy)
   URL: https://your-app.onrender.com
   Features: Auto-deploy, SSL, Custom domains

2️⃣  RAILWAY (FREE & Fast)
   URL: https://your-app.railway.app
   Features: GitHub integration, Auto-scaling

3️⃣  NETLIFY (Static - Instant)
   URL: https://your-app.netlify.app
   Features: Instant deploy, CDN, Forms

4️⃣  VERCEL (Serverless - FREE)
   URL: https://your-app.vercel.app
   Features: Global CDN, Analytics

5️⃣  HEROKU (Classic - FREE tier)
   URL: https://your-app.herokuapp.com
   Features: Add-ons, Custom domains

🔑 SETUP REQUIRED:
   Get Groq API Key: https://console.groq.com

📋 NEXT STEPS:
   1. Choose platform above
   2. Run deployment script
   3. Add GROQ_API_KEY
   4. Get your live URL!

🌟 Your MarketAI Suite will be LIVE in minutes!
""")

def open_deployment_guide():
    """Open deployment guide in browser"""
    webbrowser.open('file://' + os.path.abspath('index.html'))

if __name__ == "__main__":
    print("🚀 MarketAI Suite - Deployment Setup")
    print("=====================================")
    
    # Create deployment scripts
    create_deploy_script()
    print("✅ Deployment scripts created!")
    
    # Show options
    show_deployment_options()
    
    # Open demo page
    open_deployment_guide()
    print("🌐 Demo page opened in your browser!")
    
    print("\n🎉 Your MarketAI Suite is ready to deploy!")
    print("Choose any platform above to get your LIVE URL!")
