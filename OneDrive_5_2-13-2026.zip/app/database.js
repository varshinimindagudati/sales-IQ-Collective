// Secure Database Implementation
class SecureDatabase {
    constructor() {
        this.users = [];
        this.products = [];
        this.orders = [];
        this.sessions = new Map();
        this.initializeDemoData();
    }

    // Initialize demo users and products
    initializeDemoData() {
        // Demo Users
        this.users = [
            {
                id: 1,
                email: 'admin@marketmind.com',
                password: this.hashPassword('admin123'),
                firstName: 'Super',
                lastName: 'Admin',
                role: 'admin',
                status: 'active',
                createdAt: new Date().toISOString(),
                profile: {
                    phone: '+1-555-0101',
                    department: 'IT',
                    permissions: ['all']
                }
            },
            {
                id: 2,
                email: 'john.customer@example.com',
                password: this.hashPassword('customer123'),
                firstName: 'John',
                lastName: 'Customer',
                role: 'customer',
                status: 'active',
                createdAt: new Date().toISOString(),
                profile: {
                    phone: '+1-555-0102',
                    address: '123 Main St, New York, NY',
                    loyaltyTier: 'gold',
                    totalSpent: 5420.50
                }
            },
            {
                id: 3,
                email: 'sarah.vendor@example.com',
                password: this.hashPassword('vendor123'),
                firstName: 'Sarah',
                lastName: 'Vendor',
                role: 'vendor',
                status: 'active',
                createdAt: new Date().toISOString(),
                profile: {
                    phone: '+1-555-0103',
                    businessName: 'Tech Solutions Inc',
                    businessType: 'electronics',
                    rating: 4.8
                }
            },
            {
                id: 4,
                email: 'mike.customer@example.com',
                password: this.hashPassword('customer123'),
                firstName: 'Mike',
                lastName: 'Johnson',
                role: 'customer',
                status: 'active',
                createdAt: new Date().toISOString(),
                profile: {
                    phone: '+1-555-0104',
                    address: '456 Oak Ave, Los Angeles, CA',
                    loyaltyTier: 'silver',
                    totalSpent: 2850.75
                }
            },
            {
                id: 5,
                email: 'emma.manager@example.com',
                password: this.hashPassword('manager123'),
                firstName: 'Emma',
                lastName: 'Manager',
                role: 'manager',
                status: 'active',
                createdAt: new Date().toISOString(),
                profile: {
                    phone: '+1-555-0105',
                    department: 'Sales',
                    permissions: ['analytics', 'users', 'products']
                }
            }
        ];

        // Demo Products
        this.products = [
            {
                id: 1,
                name: 'AI Marketing Suite',
                description: 'Complete AI-powered marketing automation platform',
                category: 'Software',
                price: 299.99,
                vendorId: 3,
                stock: 50,
                rating: 4.7,
                reviews: 128,
                features: ['Email Automation', 'Lead Scoring', 'Analytics Dashboard', 'AI Content Generation'],
                images: ['product1.jpg'],
                tags: ['ai', 'marketing', 'automation']
            },
            {
                id: 2,
                name: 'Customer Analytics Pro',
                description: 'Advanced customer behavior analytics and insights',
                category: 'Software',
                price: 199.99,
                vendorId: 3,
                stock: 100,
                rating: 4.5,
                reviews: 89,
                features: ['Real-time Analytics', 'Customer Segmentation', 'Predictive Insights', 'Custom Reports'],
                images: ['product2.jpg'],
                tags: ['analytics', 'customer', 'insights']
            },
            {
                id: 3,
                name: 'Sales CRM Enterprise',
                description: 'Enterprise-grade customer relationship management',
                category: 'Software',
                price: 499.99,
                vendorId: 3,
                stock: 25,
                rating: 4.8,
                reviews: 203,
                features: ['Lead Management', 'Sales Pipeline', 'Email Integration', 'Mobile App'],
                images: ['product3.jpg'],
                tags: ['crm', 'sales', 'enterprise']
            },
            {
                id: 4,
                name: 'Social Media Manager',
                description: 'Manage all social media accounts from one platform',
                category: 'Software',
                price: 149.99,
                vendorId: 3,
                stock: 75,
                rating: 4.3,
                reviews: 67,
                features: ['Multi-platform Support', 'Scheduling', 'Analytics', 'Team Collaboration'],
                images: ['product4.jpg'],
                tags: ['social', 'media', 'management']
            },
            {
                id: 5,
                name: 'E-commerce Platform',
                description: 'Complete online store solution with AI features',
                category: 'Software',
                price: 799.99,
                vendorId: 3,
                stock: 15,
                rating: 4.9,
                reviews: 156,
                features: ['Product Management', 'Payment Processing', 'AI Recommendations', 'Mobile Responsive'],
                images: ['product5.jpg'],
                tags: ['ecommerce', 'online', 'store']
            }
        ];

        // Demo Orders
        this.orders = [
            {
                id: 1,
                customerId: 2,
                items: [
                    { productId: 1, quantity: 1, price: 299.99 },
                    { productId: 2, quantity: 2, price: 199.99 }
                ],
                total: 699.97,
                status: 'completed',
                orderDate: new Date('2024-01-15').toISOString(),
                shippingAddress: '123 Main St, New York, NY'
            },
            {
                id: 2,
                customerId: 4,
                items: [
                    { productId: 3, quantity: 1, price: 499.99 }
                ],
                total: 499.99,
                status: 'processing',
                orderDate: new Date('2024-02-20').toISOString(),
                shippingAddress: '456 Oak Ave, Los Angeles, CA'
            }
        ];
    }

    // Secure password hashing
    hashPassword(password) {
        // Simple hash for demo (use bcrypt in production)
        return btoa(password + 'marketmind_salt');
    }

    // Verify password
    verifyPassword(password, hash) {
        return this.hashPassword(password) === hash;
    }

    // User authentication
    async authenticateUser(email, password) {
        const user = this.users.find(u => u.email === email);
        if (user && this.verifyPassword(password, user.password)) {
            // Remove password from response
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    }

    // Create user session
    createSession(userId) {
        const sessionId = this.generateSessionId();
        const session = {
            id: sessionId,
            userId: userId,
            createdAt: new Date(),
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
        };
        this.sessions.set(sessionId, session);
        return sessionId;
    }

    // Validate session
    validateSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session || session.expiresAt < new Date()) {
            this.sessions.delete(sessionId);
            return null;
        }
        return session;
    }

    // Generate session ID
    generateSessionId() {
        return Math.random().toString(36).substring(2) + Date.now().toString(36);
    }

    // Get user by ID
    getUserById(id) {
        const user = this.users.find(u => u.id === id);
        if (user) {
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
        }
        return null;
    }

    // Get products
    getProducts(filters = {}) {
        let products = [...this.products];
        
        if (filters.category) {
            products = products.filter(p => p.category === filters.category);
        }
        
        if (filters.vendorId) {
            products = products.filter(p => p.vendorId === filters.vendorId);
        }
        
        if (filters.search) {
            const search = filters.search.toLowerCase();
            products = products.filter(p => 
                p.name.toLowerCase().includes(search) || 
                p.description.toLowerCase().includes(search)
            );
        }
        
        return products;
    }

    // Get orders for customer
    getCustomerOrders(customerId) {
        return this.orders.filter(o => o.customerId === customerId);
    }

    // Create order
    createOrder(customerId, items, shippingAddress) {
        const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const order = {
            id: this.orders.length + 1,
            customerId,
            items,
            total,
            status: 'pending',
            orderDate: new Date().toISOString(),
            shippingAddress
        };
        this.orders.push(order);
        return order;
    }

    // Get analytics data
    getAnalytics() {
        return {
            totalRevenue: this.orders.reduce((sum, o) => sum + o.total, 0),
            totalOrders: this.orders.length,
            totalCustomers: this.users.filter(u => u.role === 'customer').length,
            totalProducts: this.products.length,
            topProducts: this.products.sort((a, b) => b.rating - a.rating).slice(0, 5),
            recentOrders: this.orders.sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate)).slice(0, 10)
        };
    }
}

// Export database instance
const db = new SecureDatabase();
if (typeof module !== 'undefined' && module.exports) {
    module.exports = db;
} else {
    window.SecureDatabase = db;
}
