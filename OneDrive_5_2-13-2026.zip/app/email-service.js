// Email Service for Authentication
class EmailService {
    constructor() {
        this.emailQueue = [];
        this.isSimulated = true; // Set to false for real email service
    }

    // Send authentication email
    async sendAuthenticationEmail(email, loginLink) {
        const emailData = {
            to: email,
            subject: 'MarketMind - Login Authentication',
            html: this.generateAuthEmailTemplate(email, loginLink),
            text: `Please click this link to login to MarketMind: ${loginLink}`
        };

        if (this.isSimulated) {
            return this.simulateEmailSend(emailData);
        } else {
            return this.sendRealEmail(emailData);
        }
    }

    // Generate email template
    generateAuthEmailTemplate(email, loginLink) {
        return `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>MarketMind Login</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
                .logo { font-size: 24px; font-weight: bold; margin-bottom: 10px; }
                .security-info { background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div class="logo">🧠 MarketMind</div>
                    <h1>Authentication Required</h1>
                </div>
                <div class="content">
                    <h2>Hello,</h2>
                    <p>You requested to login to MarketMind using the email: <strong>${email}</strong></p>
                    
                    <div class="security-info">
                        <h3>🔒 Security Notice</h3>
                        <p>This login link will expire in 15 minutes for your security. If you didn't request this login, please ignore this email.</p>
                    </div>
                    
                    <p>Click the button below to securely login to your account:</p>
                    
                    <div style="text-align: center;">
                        <a href="${loginLink}" class="button">🚀 Login to MarketMind</a>
                    </div>
                    
                    <p>Or copy and paste this link in your browser:</p>
                    <p style="word-break: break-all; background: #eee; padding: 10px; border-radius: 5px;">${loginLink}</p>
                    
                    <p><strong>Important:</strong></p>
                    <ul>
                        <li>This link can only be used once</li>
                        <li>It expires in 15 minutes</li>
                        <li>Never share this link with anyone</li>
                    </ul>
                </div>
                <div class="footer">
                    <p>© 2026 MarketMind. All rights reserved.</p>
                    <p>This is an automated message, please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        `;
    }

    // Simulate email sending (for demo)
    simulateEmailSend(emailData) {
        return new Promise((resolve) => {
            setTimeout(() => {
                console.log('📧 Email sent:', emailData);
                this.emailQueue.push({
                    ...emailData,
                    sentAt: new Date(),
                    id: Math.random().toString(36).substring(7)
                });
                resolve({
                    success: true,
                    messageId: Math.random().toString(36).substring(7),
                    message: 'Authentication email sent successfully'
                });
            }, 1000);
        });
    }

    // Send real email (integration with email service)
    async sendRealEmail(emailData) {
        // This would integrate with services like:
        // - SendGrid
        // - AWS SES
        // - Mailgun
        // - SMTP
        
        try {
            const response = await fetch('/api/send-email', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(emailData)
            });
            
            return await response.json();
        } catch (error) {
            console.error('Email send error:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Get sent emails (for demo purposes)
    getSentEmails() {
        return this.emailQueue;
    }

    // Clear email queue
    clearEmailQueue() {
        this.emailQueue = [];
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EmailService;
} else {
    window.EmailService = EmailService;
}
