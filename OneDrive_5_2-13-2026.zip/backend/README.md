# MarketMind Backend - Enterprise-Grade API Server

## 🚀 Overview
This is the robust backend system for MarketMind AI Sales & Marketing Intelligence Platform. Built with enterprise-grade technologies to ensure high performance, scalability, and reliability.

## 🛠️ Technology Stack

### **Core Technologies**
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **PostgreSQL** - Primary database (ACID compliant, highly reliable)
- **Redis** - Caching and session management
- **JWT** - Authentication tokens
- **Socket.io** - Real-time communication

### **Security & Performance**
- **Helmet** - Security headers
- **Bcrypt** - Password hashing
- **Rate Limiting** - DDoS protection
- **Compression** - Response optimization
- **Winston** - Advanced logging

## 📋 Features

### **Authentication & Authorization**
- Secure user registration and login
- JWT-based authentication
- Role-based access control (Vendor, Customer, Admin)
- Password reset functionality
- Email verification

### **Database Architecture**
- **PostgreSQL** for primary data storage
- **Connection pooling** for performance
- **Database migrations** for schema management
- **Full-text search** indexes
- **Redis caching** for frequently accessed data

### **User Management**
- Multi-user support (Vendors & Customers)
- Profile management
- Preference settings
- Activity tracking
- Status management

### **Security Features**
- Input validation with Joi
- SQL injection prevention
- XSS protection
- CORS configuration
- Rate limiting
- Request logging

## 🏗️ Project Structure

```
backend/
├── config/
│   └── database.js          # Database configuration
├── middleware/
│   ├── auth.js              # Authentication middleware
│   └── errorHandler.js      # Error handling
├── migrations/              # Database migrations
├── routes/
│   ├── auth.js              # Authentication routes
│   ├── users.js             # User management
│   ├── vendors.js           # Vendor management
│   ├── customers.js         # Customer management
│   ├── analytics.js         # Analytics endpoints
│   └── automation.js        # Automation workflows
├── utils/
│   └── logger.js            # Logging configuration
├── uploads/                 # File uploads
├── logs/                    # Log files
├── package.json
├── server.js                # Main server file
└── .env.example             # Environment variables
```

## 🚀 Quick Start

### **Prerequisites**
- Node.js 18+
- PostgreSQL 13+
- Redis 6+
- npm or yarn

### **Installation**

1. **Clone and install dependencies**
```bash
cd backend
npm install
```

2. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env with your configuration
```

3. **Set up PostgreSQL database**
```sql
CREATE DATABASE marketmind_db;
CREATE USER marketmind_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE marketmind_db TO marketmind_user;
```

4. **Run database migrations**
```bash
npm run migrate
```

5. **Seed database (optional)**
```bash
npm run seed
```

6. **Start the server**
```bash
# Development
npm run dev

# Production
npm start
```

## 📊 Database Schema

### **Users Table**
- User authentication data
- Profile information
- User roles and status

### **Vendors Table**
- Business information
- Verification status
- Business details and settings

### **Customers Table**
- Customer profiles
- Purchase history
- Loyalty and segmentation data

## 🔒 Security Features

### **Password Security**
- Bcrypt hashing with 12 salt rounds
- Strong password requirements
- Password reset tokens

### **API Security**
- JWT authentication
- Rate limiting (100 requests per 15 minutes)
- Input validation and sanitization
- SQL injection prevention

### **Data Protection**
- Environment variable encryption
- Secure headers with Helmet
- CORS configuration
- Request logging and monitoring

## 📈 Performance Features

### **Database Optimization**
- Connection pooling (2-20 connections)
- Indexed queries
- Full-text search capabilities
- Query optimization

### **Caching Strategy**
- Redis for session storage
- Query result caching
- API response caching
- Real-time data synchronization

### **Monitoring & Logging**
- Winston logging with multiple levels
- Error tracking and reporting
- Performance monitoring
- Health check endpoints

## 🔗 API Endpoints

### **Authentication**
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `POST /api/auth/refresh` - Refresh token
- `POST /api/auth/logout` - User logout

### **Health Check**
- `GET /health` - System health status

### **Users Management**
- `GET /api/users` - Get users (admin only)
- `GET /api/users/:id` - Get user by ID
- `PUT /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user

### **Vendors**
- `GET /api/vendors` - Get vendors
- `POST /api/vendors` - Create vendor
- `PUT /api/vendors/:id` - Update vendor
- `GET /api/vendors/:id/analytics` - Vendor analytics

### **Customers**
- `GET /api/customers` - Get customers
- `POST /api/customers` - Create customer
- `PUT /api/customers/:id` - Update customer
- `GET /api/customers/:id/analytics` - Customer analytics

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

## 📝 Environment Variables

Key environment variables:

- `NODE_ENV` - Environment (development/production)
- `PORT` - Server port (default: 5000)
- `DB_HOST` - PostgreSQL host
- `DB_USER` - Database user
- `DB_PASSWORD` - Database password
- `DB_NAME` - Database name
- `REDIS_HOST` - Redis host
- `JWT_SECRET` - JWT secret key
- `FRONTEND_URL` - Frontend URL for CORS

## 🚀 Deployment

### **Docker Deployment**
```bash
# Build image
docker build -t marketmind-backend .

# Run container
docker run -p 5000:5000 --env-file .env marketmind-backend
```

### **Production Considerations**
- Use HTTPS in production
- Set up reverse proxy (Nginx)
- Configure database backups
- Set up monitoring and alerts
- Use environment-specific configurations

## 📊 Monitoring

### **Health Checks**
- Database connectivity
- Redis connectivity
- Memory usage
- System uptime

### **Logging**
- Error logs
- Access logs
- Performance metrics
- Security events

## 🔧 Maintenance

### **Database Maintenance**
- Regular backups
- Query optimization
- Index maintenance
- Log rotation

### **Security Updates**
- Regular dependency updates
- Security patch management
- Vulnerability scanning
- Access review

## 📞 Support

For technical support or questions:
- Check the logs for error details
- Review the health check endpoint
- Verify database connectivity
- Check environment configuration

---

**Built with ❤️ for MarketMind AI Platform**
