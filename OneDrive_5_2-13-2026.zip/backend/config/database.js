const knex = require('knex');
const dotenv = require('dotenv');

dotenv.config();

// PostgreSQL Configuration for Enterprise Database
const db = knex({
  client: 'pg',
  connection: {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'marketmind_user',
    password: process.env.DB_PASSWORD || 'secure_password',
    database: process.env.DB_NAME || 'marketmind_db',
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    pool: {
      min: 2,
      max: 20,
      acquireTimeoutMillis: 60000,
      createTimeoutMillis: 30000,
      destroyTimeoutMillis: 5000,
      idleTimeoutMillis: 30000,
      reapIntervalMillis: 1000,
      createRetryIntervalMillis: 100,
      propagateCreateError: false
    }
  },
  migrations: {
    directory: './migrations',
    tableName: 'knex_migrations'
  },
  seeds: {
    directory: './seeds'
  },
  debug: process.env.NODE_ENV === 'development'
});

// Redis Configuration for Caching and Sessions
const redis = require('redis');
const redisClient = redis.createClient({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD || '',
  db: process.env.REDIS_DB || 0,
  retryDelayOnFailover: 100,
  enableReadyCheck: false,
  maxRetriesPerRequest: null,
  lazyConnect: true
});

redisClient.on('error', (err) => {
  console.error('Redis Error:', err);
});

redisClient.on('connect', () => {
  console.log('Redis Connected Successfully');
});

// Database Health Check
const checkDatabaseHealth = async () => {
  try {
    await db.raw('SELECT 1');
    return { status: 'healthy', database: 'postgresql' };
  } catch (error) {
    return { status: 'unhealthy', error: error.message };
  }
};

// Redis Health Check
const checkRedisHealth = async () => {
  try {
    await redisClient.ping();
    return { status: 'healthy', database: 'redis' };
  } catch (error) {
    return { status: 'unhealthy', error: error.message };
  }
};

// Connection Pool Monitoring
const monitorConnections = () => {
  const pool = db.client.pool;
  console.log('Database Pool Status:', {
    used: pool.numUsed(),
    free: pool.numFree(),
    pending: pool.numPendingAcquires(),
    total: pool.numUsed() + pool.numFree()
  });
};

module.exports = {
  db,
  redisClient,
  checkDatabaseHealth,
  checkRedisHealth,
  monitorConnections
};
