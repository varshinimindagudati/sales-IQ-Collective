exports.up = function(knex) {
  return knex.schema.createTable('vendors', function(table) {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    table.string('business_name').notNullable();
    table.string('business_type').notNullable(); // retail, service, manufacturing, etc.
    table.string('industry').notNullable();
    table.string('tax_id').nullable();
    table.string('license_number').nullable();
    table.text('description').nullable();
    table.string('website').nullable();
    table.jsonb('business_address').notNullable(); // Structured address data
    table.jsonb('billing_address').nullable();
    table.string('contact_person').notNullable();
    table.string('contact_email').notNullable();
    table.string('contact_phone').notNullable();
    table.enum('verification_status', ['pending', 'verified', 'rejected']).notNullable().defaultTo('pending');
    table.timestamp('verified_at').nullable();
    table.string('verified_by').nullable();
    table.jsonb('verification_documents').nullable(); // Store document URLs
    table.decimal('rating', 3, 2).defaultTo(0); // Average rating
    table.integer('total_reviews').defaultTo(0);
    table.jsonb('business_hours').nullable(); // Operating hours
    table.jsonb('social_media').nullable(); // Social media links
    table.boolean('featured').defaultTo(false);
    table.timestamp('featured_until').nullable();
    table.jsonb('settings').nullable(); // Vendor-specific settings
    table.timestamps(true, true);
    
    // Indexes for performance
    table.index(['user_id']);
    table.index(['business_name']);
    table.index(['industry']);
    table.index(['verification_status']);
    table.index(['rating']);
    table.index(['featured']);
    table.index(['created_at']);
    
    // Full-text search index
    table.raw(`CREATE INDEX vendors_search_idx ON vendors USING gin(to_tsvector('english', business_name || ' ' || description || ' ' || industry))`);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists('vendors');
};
