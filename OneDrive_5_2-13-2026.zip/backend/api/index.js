const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// In-memory database for demo
const users = [];
const vendors = [];
const customers = [];

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    message: 'MarketMind Backend is running'
  });
});

// Auth endpoints
app.post('/api/auth/register', (req, res) => {
  const { email, password, firstName, lastName, userType } = req.body;
  
  const newUser = {
    id: uuidv4(),
    email,
    firstName,
    lastName,
    userType,
    createdAt: new Date().toISOString()
  };
  
  users.push(newUser);
  
  res.json({
    success: true,
    message: 'User registered successfully',
    data: {
      user: newUser,
      token: 'demo-jwt-token-' + uuidv4()
    }
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  const user = users.find(u => u.email === email);
  
  if (user) {
    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user,
        token: 'demo-jwt-token-' + uuidv4()
      }
    });
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid credentials'
    });
  }
});

// Analytics endpoints
app.get('/api/analytics/dashboard', (req, res) => {
  res.json({
    success: true,
    data: {
      totalRevenue: 124563,
      activeCustomers: 2847,
      conversionRate: 3.8,
      aiScore: 94.2,
      salesTrends: [
        { month: 'Jan', revenue: 65000 },
        { month: 'Feb', revenue: 78000 },
        { month: 'Mar', revenue: 90000 },
        { month: 'Apr', revenue: 81000 },
        { month: 'May', revenue: 96000 },
        { month: 'Jun', revenue: 124563 }
      ],
      customerSegments: [
        { segment: 'High Value', count: 342 },
        { segment: 'New', count: 567 },
        { segment: 'At Risk', count: 47 },
        { segment: 'Regular', count: 1234 },
        { segment: 'VIP', count: 657 }
      ]
    }
  });
});

// Content generation endpoint
app.post('/api/content/generate', (req, res) => {
  const { contentType, audience } = req.body;
  
  const templates = {
    email: {
      new: {
        subject: "Welcome to MarketMind! 🎉",
        body: "Hi {{name}},\n\nWelcome to our community! We're excited to have you on board. As a new member, you'll receive:\n\n• Personalized product recommendations\n• Exclusive member-only offers\n• Early access to new features\n\nGet started with our special 15% discount on your first purchase!\n\nBest regards,\nThe MarketMind Team"
      },
      vip: {
        subject: "Exclusive VIP Offer Just for You 💎",
        body: "Dear {{name}},\n\nAs one of our most valued customers, we wanted to thank you with an exclusive offer:\n\n• 25% discount on your next purchase\n• Free priority shipping\n• Early access to new collection\n\nYour loyalty means everything to us. Use code VIP25 at checkout.\n\nWarmly,\nThe MarketMind VIP Team"
      }
    },
    social: {
      new: "🚀 New to MarketMind? Discover how AI can transform your business! Get 15% off your first order. #AI #Marketing #Sales #Innovation",
      vip: "💎 VIP Exclusive! Our top customers get special treatment. 25% off + free shipping this week only. Don't miss out! #VIP #Exclusive #Premium"
    }
  };
  
  const content = templates[contentType]?.[audience] || templates.email.new;
  
  res.json({
    success: true,
    data: content
  });
});

// Automation endpoints
app.get('/api/automation/workflows', (req, res) => {
  res.json({
    success: true,
    data: [
      {
        id: 1,
        name: 'Welcome Series',
        description: 'New customer onboarding',
        status: 'active',
        performance: {
          openRate: 68.4,
          clickRate: 24.7,
          conversionRate: 12.3
        }
      },
      {
        id: 2,
        name: 'Abandoned Cart Recovery',
        description: 'Recover lost sales',
        status: 'active',
        performance: {
          openRate: 72.1,
          clickRate: 31.2,
          conversionRate: 18.9
        }
      },
      {
        id: 3,
        name: 'VIP Customer Nurturing',
        description: 'High-value customer care',
        status: 'paused',
        performance: {
          openRate: 85.3,
          clickRate: 42.7,
          conversionRate: 28.4
        }
      }
    ]
  });
});

// AI Analytics endpoints
app.get('/api/analytics/ai-insights', (req, res) => {
  res.json({
    success: true,
    data: {
      predictiveLeadScoring: {
        topLead: {
          name: 'John Doe',
          email: 'john@example.com',
          score: 92,
          probability: 'High'
        }
      },
      customerSegmentation: {
        highValue: 342,
        new: 567,
        atRisk: 47
      },
      churnPrediction: {
        atRiskCustomers: 47,
        warningThreshold: 0.7
      }
    }
  });
});

// Export for Vercel
module.exports = app;
